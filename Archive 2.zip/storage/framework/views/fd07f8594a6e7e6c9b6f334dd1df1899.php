<?php $__env->startSection('content'); ?>

<?php $__env->startSection('breadcrumb_parent', 'Tests'); ?>
<?php $__env->startSection('breadcrumb_child', 'Add Test'); ?>

<div class="row">
    <div class="col-xl-12">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title mb-0"><?php echo $__env->yieldContent('breadcrumb_child'); ?></h5>
            </div>
            <div class="card-body">
                <?php if(session('success')): ?>
                    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                <?php endif; ?>

                <form method="POST" action="<?php echo e(route('admin.test.store')); ?>">
                    <?php echo csrf_field(); ?>

                    <!-- Test Name -->
                    <div class="mb-3">
                        <label for="testName" class="form-label">Test Name</label>
                        <input type="text" name="testName" id="testName" class="form-control" 
                               value="<?php echo e(old('testName')); ?>" required>
                    </div>

                    <!-- Test Category (Dropdown) -->
                    <div class="mb-3">
                        <label for="testCatId" class="form-label">Test Category</label>
                        <select name="testCatId" id="testCatId" class="form-select">
                            <option value="" selected disabled>Select a category</option>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($category->testCatId); ?>"
                                    <?php echo e(old('testCatId') == $category->testCatId ? 'selected' : ''); ?>>
                                    <?php echo e($category->testCat); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <!-- Test Cost -->
                    <div class="mb-3">
                        <label for="testCost" class="form-label">Test Cost</label>
                        <input type="number" step="0.01" name="testCost" id="testCost" class="form-control" 
                               value="<?php echo e(old('testCost', 0)); ?>" required>
                    </div>

                    <!-- How to Take Sample (Dropdown) -->
                    <div class="mb-3">
                        <label for="howSample" class="form-label">How to Take Sample</label>
                        <select name="howSample" id="howSample" class="form-select">
                            <option value="" selected disabled>Select sample instructions</option>
                            <?php $__currentLoopData = $howSampleOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($key); ?>"
                                    <?php echo e(old('howSample') == $key ? 'selected' : ''); ?>>
                                    <?php echo e($value); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <!-- Sample Type (Dropdown) -->
                    <div class="mb-3">
                        <label for="typeSample" class="form-label">Sample Type</label>
                        <select name="typeSample" id="typeSample" class="form-select">
                            <option value="" selected disabled>Select sample type</option>
                            <?php $__currentLoopData = $sampleTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($key); ?>"
                                    <?php echo e(old('typeSample') == $key ? 'selected' : ''); ?>>
                                    <?php echo e($value); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <!-- Submit Button -->
                    <button type="submit" class="btn btn-primary">Create Test</button>
                </form>
            </div><!-- end card-body -->
        </div><!-- end card -->
    </div><!-- end col -->
</div><!-- end row -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/htdocs/fyp/resources/views/admin/pages/test/create.blade.php ENDPATH**/ ?>