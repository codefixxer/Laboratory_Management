<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Customer Details</h2>
    <div class="card">
        <div class="card-body">
            <p><strong>Customer ID:</strong> <?php echo e($customer->customerId); ?></p>
            <p><strong>Name:</strong> <?php echo e($customer->name); ?></p>
            <p><strong>Email:</strong> <?php echo e($customer->email); ?></p>
            <p><strong>Phone:</strong> <?php echo e($customer->phone); ?></p>
        </div>
    </div>

    <h3>Test Details</h3>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Test ID</th>
                <th>Test Name</th>
                <th>Sample Type</th>
                <th>How Sample Collected</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $tests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $test): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($test->addTestId); ?></td>
                <td><?php echo e($test->test->testName); ?></td>
                <td><?php echo e($test->test->typeSample); ?></td>
                <td><?php echo e($test->test->howSample); ?></td>
                <td>
                    <a href="<?php echo e(route('report.test', ['addTestId' => $test->addTestId, 'customerId' => $customer->customerId])); ?>" class="btn btn-primary">
                        Report Test
                    </a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('reporter.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/htdocs/fyp/resources/views/reporter/pages/test-details.blade.php ENDPATH**/ ?>