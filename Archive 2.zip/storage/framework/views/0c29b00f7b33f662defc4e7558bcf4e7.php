<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <h2 class="mb-4">Accepted Reports</h2>

    <?php if($reports->isEmpty()): ?>
        <p>No accepted reports found.</p>
    <?php else: ?>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Report ID</th>
                    <th>Customer Name</th>
                    <th>Customer Id</th>
                    <th>Test Name</th>
                    <th>Sign Status</th>
                    <th>Created Date</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        // Assume each customer has at least one payment record;
                        // adjust logic if there might be multiple.
                        $payment = $report->customerTest->customer->payments->first();
                    ?>
                    <tr>
                        <td><?php echo e($report->reportId); ?></td>
                        <td><?php echo e($report->customerTest->customer->customerId ?? 'N/A'); ?></td>
                        <td><?php echo e($report->customerTest->customer->name ?? 'N/A'); ?></td>
                        <td><?php echo e(optional($report->customerTest->test)->testName ?? 'N/A'); ?></td>
                        <td><?php echo e(ucfirst($report->signStatus)); ?></td>
                        <td><?php echo e($report->created_at); ?></td>
                        <td>
                            <?php if($payment && $payment->pending == 0): ?> 
                                <a href="<?php echo e(route('receptionist.customer.details', $report->reportId)); ?>" class="btn btn-info">View Report</a>
                            <?php else: ?>
                                <a href="<?php echo e(route('receptionist.pay.pending', $report->customerTest->customer->customerId)); ?>" class="btn btn-warning">Pay Pending</a>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table> 
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('receptionist.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/htdocs/fyp/resources/views/receptionist/pages/customers/signed.blade.php ENDPATH**/ ?>