<?php $__env->startSection('content'); ?>
<div class="container my-5 invoice-container">

  
  <div class="row align-items-center mb-4">
    <div class="col-8">
      <h1 class="display-4 text-primary">Invoice</h1>
      <p class="mb-1">Invoice #: <strong>INV-<?php echo e($customer->customerId); ?></strong></p>
      <p>Date: <strong><?php echo e(now()->format('Y-m-d')); ?></strong></p>
    </div>
    <div class="col-4 text-end">
      
      <button onclick="window.print()" class="btn btn-outline-primary mb-2 d-print-none">
        <i class="bi bi-printer"></i> Print Invoice
      </button>
      <div>
        <img src="/images/logo.png" alt="Lab Logo" style="height:80px;">
      </div>
    </div>
  </div>

  
  <div class="mb-4 text-end">
    <?php if($customer->payment->pending == 0): ?>
      <span class="badge bg-success fs-5">PAID</span>
    <?php else: ?>
      <span class="badge bg-warning fs-5">DUE</span>
    <?php endif; ?>
  </div>

  
  <div class="card mb-4 shadow-sm border-primary">
    <div class="card-body">
      <h5 class="card-title text-primary">Patient Details</h5>
      <p><strong>Name:</strong> <?php echo e($customer->title); ?> <?php echo e($customer->name); ?></p>
      <p><strong>Username:</strong> <?php echo e($customer->user_name); ?></p>
      <p><strong>Phone:</strong> +92<?php echo e($customer->phone); ?></p>
      <p><strong>Email:</strong> <?php echo e($customer->email ?? '—'); ?></p>
      <p><strong>Relation:</strong> <?php echo e($customer->relation); ?></p>
    </div>
  </div>

  
  <div class="card mb-4 shadow-sm border-info">
    <div class="card-body">
      <h5 class="card-title text-info">Selected Tests</h5>
      <table class="table table-striped mb-0">
        <thead class="table-dark">
          <tr>
            <th>#</th>
            <th>Test Name</th>
            <th>Category</th>
            <th class="text-end">Cost (₹)</th>
          </tr>
        </thead>
        <tbody>
          <?php $subtotal = 0; ?>
          <?php $__currentLoopData = $customer->customerTests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $ct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
              $t     = $ct->test;
              $cat   = $t->category->testCat ?? '—';
              $cost  = $t->testCost;
              $subtotal += $cost;
            ?>
            <tr>
              <td><?php echo e($i+1); ?></td>
              <td><?php echo e($t->testName); ?></td>
              <td><?php echo e($cat); ?></td>
              <td class="text-end"><?php echo e(number_format($cost,2)); ?></td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
  </div>

  
  <div class="row mb-4">
    <div class="col-md-6">
      <div class="card shadow-sm p-3 border-secondary">
        <h6 class="text-secondary">Referral / Panel</h6>
        <?php if($customer->staffPanel): ?>
          <p>Type: <strong>Staff Panel</strong></p>
          <p>By: <strong><?php echo e($customer->staffPanel->user->name); ?></strong></p>
        <?php elseif($customer->externalPanel): ?>
          <p>Type: <strong>External Panel</strong></p>
          <p>Panel: <strong><?php echo e($customer->externalPanel->panelName); ?></strong></p>
        <?php elseif($customer->referral): ?>
          <p>Referrer: <strong><?php echo e($customer->referral->referrerName); ?></strong></p>
        <?php else: ?>
          <p><em>None</em></p>
        <?php endif; ?>
      </div>
    </div>
    
    <div class="col-md-6">
      <div class="card shadow-sm p-3 border-dark">
        <h6 class="text-dark">Billing Summary</h6>
        <table class="table border-0 mb-0">
          <tr>
            <th>Subtotal:</th>
            <td class="text-end">₹<?php echo e(number_format($subtotal,2)); ?></td>
          </tr>
          <tr>
            <th>Discount:</th>
            <td class="text-end">
              ₹<?php echo e(number_format($subtotal - ($customer->payment->recieved + $customer->payment->pending),2)); ?>

            </td>
          </tr>
          <tr>
            <th>Paid:</th>
            <td class="text-end text-success">₹<?php echo e(number_format($customer->payment->recieved,2)); ?></td>
          </tr>
          <tr>
            <th>Due:</th>
            <td class="text-end text-danger">₹<?php echo e(number_format($customer->payment->pending,2)); ?></td>
          </tr>
          <tr class="table-active">
            <th>Total:</th>
            <th class="text-end">₹<?php echo e(number_format($subtotal,2)); ?></th>
          </tr>
        </table>
      </div>
    </div>
  </div>

  
  <div class="row mt-5">
    <div class="col-6">
      <p>__________________________</p>
      <p><strong>Authorized Signatory</strong></p>
    </div>
    <div class="col-6 text-end">
      <p>__________________________</p>
      <p><strong>Patient Signature</strong></p>
    </div>
  </div>

  
  <div class="text-center text-mu.ted mt-4">
    <p>Thank you for choosing <strong>Medicore Lab</strong>!</p>
    <small>123 Lab Street, Karachi • +92-300-1234567 • info@handsomelab.com</small>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
<style>
  .invoice-container {
    border: 2px solid #dee2e6;
    padding: 30px;
    border-radius: 10px;
    background: #fff;
  }
  table.table-striped tbody tr:nth-of-type(odd) {
    background-color: #f8f9fa;
  }
  /* Print-specific rules */
  @media print {
    .d-print-none { display: none !important; }
    .invoice-container { box-shadow: none; border: none; }
  }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('receptionist.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/htdocs/fyp/resources/views/receptionist/pages/invoice/index.blade.php ENDPATH**/ ?>