<?php $__env->startSection('content'); ?>

<?php $__env->startSection('breadcrumb_parent', 'User Management'); ?>
<?php $__env->startSection('breadcrumb_child', 'Users List'); ?>



 

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h5 class="card-title mb-0"><?php echo $__env->yieldContent('breadcrumb_child'); ?></h5>
                </div>

                <div class="card-body">
                  
 <!-- resources/views/admin/pages/users/index.blade.php -->
<table id="datatable" class="table table-bordered dt-responsive nowrap w-100">
    <thead>
        <tr>
            <th>Profile</th>
            <th>Name</th>
            <th>Email</th>
            <th>Role</th>
            <th>Phone</th>
            <th>Status</th>
            <th>Created At</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <!-- Display Profile Picture (if exists) -->
            <td>
                <?php if($user->profile_picture): ?>
                <img 
                src="<?php echo e(asset('storage/' . $user->profile_picture)); ?>" 
                alt="Profile Picture" 
                width="50" 
                height="50" 
                style="
                    object-fit: cover; 
                    border-radius: 50%;            /* Make it a circle */
                    border: 2px solid #fff;        /* Main white border */
                    border-top: 5px solid #287f71; /* Thicker top border in a color (e.g., blue) */
                    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2); /* Soft shadow */
                "
            >
                            <?php else: ?>
                    <img src="<?php echo e(asset('assets/images/users/dp.jpg')); ?>" alt="DP"  width="50" 
                    height="50" 
                    style="
                        object-fit: cover; 
                        border-radius: 50%;            /* Make it a circle */
                        border: 2px solid #fff;        /* Main white border */
                        border-top: 5px solid #287f71; /* Thicker top border in a color (e.g., blue) */
                        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2); /* Soft shadow */
                    ">
                <?php endif; ?>
            </td>

            <td><?php echo e($user->name); ?></td>
            <td><?php echo e($user->email); ?></td>
            <td><?php echo e(ucfirst($user->role)); ?></td>
            <td><?php echo e($user->phone); ?></td>

            <td>
                <form action="<?php echo e(route('admin.users.updateStatus', $user->id)); ?>" method="POST" class="d-inline-block">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="input-group">
                        <select name="status" class="form-select form-select-sm" onchange="this.form.submit()">
                            <option value="active"   <?php echo e($user->status === 'active'   ? 'selected' : ''); ?>>Active</option>
                            <option value="inactive" <?php echo e($user->status === 'inactive' ? 'selected' : ''); ?>>Inactive</option>
                        </select>
                    </div>
                </form>
            </td>

            <td><?php echo e($user->created_at->format('Y-m-d')); ?></td>

            <td>
                <a href="<?php echo e(route('admin.users.edit', $user->id)); ?>" class="btn btn-sm btn-primary">Edit</a>
                <form action="<?php echo e(route('admin.users.destroy', $user->id)); ?>" method="POST" class="d-inline-block" onsubmit="return confirm('Are you sure you want to delete this user?');">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>


                </div>

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/htdocs/fyp/resources/views/admin/pages/users/index.blade.php ENDPATH**/ ?>