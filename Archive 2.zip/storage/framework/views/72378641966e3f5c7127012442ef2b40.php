<?php $__env->startSection('content'); ?>
<div class="container-fluid my-4">

  
  <div class="row mb-3">
    <div class="col"><h2 class="fw-bold">Expense Report</h2></div>
  </div>

  
  <div class="row g-3 mb-4">
    <div class="col-md-4">
      <label class="form-label">Search</label>
      <input type="text" id="searchInput" class="form-control" placeholder="Search user, detail, item or date...">
    </div>
    <div class="col-md-3">
      <label class="form-label">From</label>
      <input type="date" id="fromDate" class="form-control">
    </div>
    <div class="col-md-3">
      <label class="form-label">To</label>
      <input type="date" id="toDate" class="form-control">
    </div>
    <div class="col-md-2 d-flex align-items-end">
      <button id="resetBtn" class="btn btn-secondary w-100">Reset All</button>
    </div>
  </div>

  
  <div class="row g-4 mb-5">
    <div class="col-md-4">
      <div class="card text-white bg-danger h-100">
        <div class="card-body">
          <h5 class="card-title">Total Debits</h5>
          <p class="display-6" id="totalDebits">₹<?php echo e(number_format($totalDebits, 2)); ?></p>
        </div>
      </div>
    </div>
    <div class="col-md-4">
      <div class="card text-white bg-warning h-100">
        <div class="card-body">
          <h5 class="card-title">Stock Purchases</h5>
          <p class="display-6" id="totalStockCost">₹<?php echo e(number_format($totalStockCost, 2)); ?></p>
        </div>
      </div>
    </div>
    <div class="col-md-4">
      <div class="card text-white bg-dark h-100">
        <div class="card-body">
          <h5 class="card-title">Total Expense</h5>
          <p class="display-6" id="totalExpense">₹<?php echo e(number_format($totalExpense, 2)); ?></p>
        </div>
      </div>
    </div>
  </div>

  
  <div class="row g-4">
    
    <div class="col-md-6">
      <div class="card shadow-sm">
        <div class="card-header bg-light">
          <h5 class="mb-0">Debits</h5>
        </div>
        <div class="card-body p-0">
          <table class="table table-hover mb-0" id="debitsTable">
            <thead class="table-light">
              <tr>
                <th>#</th>
                <th>User</th>
                <th>Detail</th>
                <th class="text-end">Amount</th>
                <th>Date</th>
              </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $debits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr
                data-date="<?php echo e(\Carbon\Carbon::parse($d->createdDate)->toDateString()); ?>"
                data-search="<?php echo e(strtolower($d->user->name.' '.$d->debitDetail)); ?>"
                data-amount="<?php echo e($d->debitAmount); ?>"
              >
                <td><?php echo e($loop->iteration); ?></td>
                <td><?php echo e($d->user->name); ?></td>
                <td><?php echo e($d->debitDetail); ?></td>
                <td class="text-end text-danger">₹<?php echo e(number_format($d->debitAmount, 2)); ?></td>
                <td><?php echo e(\Carbon\Carbon::parse($d->createdDate)->format('Y-m-d')); ?></td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>

    
    <div class="col-md-6">
      <div class="card shadow-sm">
        <div class="card-header bg-light">
          <h5 class="mb-0">Stock Purchases</h5>
        </div>
        <div class="card-body p-0">
          <table class="table table-hover mb-0" id="stocksTable">
            <thead class="table-light">
              <tr>
                <th>#</th>
                <th>Item</th>
                <th>Detail</th>
                <th class="text-end">Qty × Price</th>
                <th>Date</th>
              </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $stocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php $cost = $s->itmQnt * $s->itmPrice; ?>
              <tr
                data-date="<?php echo e(\Carbon\Carbon::parse($s->createdDate)->toDateString()); ?>"
                data-search="<?php echo e(strtolower($s->itemName.' '.$s->itemDetail)); ?>"
                data-amount="<?php echo e($cost); ?>"
              >
                <td><?php echo e($loop->iteration); ?></td>
                <td><?php echo e($s->itemName); ?></td>
                <td><?php echo e($s->itemDetail); ?></td>
                <td class="text-end">₹<?php echo e(number_format($cost, 2)); ?></td>
                <td><?php echo e(\Carbon\Carbon::parse($s->createdDate)->format('Y-m-d')); ?></td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
  const debitRows = Array.from(document.querySelectorAll('#debitsTable tbody tr'));
  const stockRows = Array.from(document.querySelectorAll('#stocksTable tbody tr'));
  const fromInput = document.getElementById('fromDate');
  const toInput   = document.getElementById('toDate');
  const searchInput = document.getElementById('searchInput');

  function applyExpenseFilters() {
    const from = fromInput.value;
    const to   = toInput.value;
    const term = searchInput.value.toLowerCase();

    let sumDebits = 0, sumStock = 0;

    debitRows.forEach(row => {
      const date = row.dataset.date;
      const txt  = row.dataset.search;
      const amt  = parseFloat(row.dataset.amount);

      const inDate = (!from || date >= from) && (!to || date <= to);
      const inText = !term || txt.includes(term);

      row.style.display = (inDate && inText) ? '' : 'none';
      if (inDate && inText) sumDebits += amt;
    });

    stockRows.forEach(row => {
      const date = row.dataset.date;
      const txt  = row.dataset.search;
      const amt  = parseFloat(row.dataset.amount);

      const inDate = (!from || date >= from) && (!to || date <= to);
      const inText = !term || txt.includes(term);

      row.style.display = (inDate && inText) ? '' : 'none';
      if (inDate && inText) sumStock += amt;
    });

    document.getElementById('totalDebits')   .innerText = '₹' + sumDebits.toFixed(2);
    document.getElementById('totalStockCost').innerText = '₹' + sumStock.toFixed(2);
    document.getElementById('totalExpense')  .innerText = '₹' + (sumDebits + sumStock).toFixed(2);
  }

  fromInput.addEventListener('change', applyExpenseFilters);
  toInput  .addEventListener('change', applyExpenseFilters);
  searchInput.addEventListener('input', applyExpenseFilters);

  document.getElementById('resetBtn').addEventListener('click', () => {
    fromInput.value = '';
    toInput.value   = '';
    searchInput.value = '';
    applyExpenseFilters();
  });

  applyExpenseFilters();
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/htdocs/fyp/resources/views/admin/pages/reports/expenses.blade.php ENDPATH**/ ?>