<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Credit Transactions</h2>
    <a href="<?php echo e(route('credit.create')); ?>" class="btn btn-primary">Add New Credit</a>
    
    <table class="table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Amount</th>
                <th>Details</th>
                <th>Created Date</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $credits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $credit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($credit->creditAi); ?></td>
                <td><?php echo e($credit->creditAmount); ?></td>
                <td><?php echo e($credit->creditDetail); ?></td>
                <td><?php echo e($credit->createdDate); ?></td>
                <td>
                    <form action="<?php echo e(route('credit.destroy', $credit->creditAi)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger">Delete</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('receptionist.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/htdocs/fyp/resources/views/receptionist/pages/credit/index.blade.php ENDPATH**/ ?>