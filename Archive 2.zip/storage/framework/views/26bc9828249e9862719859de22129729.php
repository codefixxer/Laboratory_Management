<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Test Report</h2>

    <div class="card">
        <div class="card-body">
            <p><strong>Test Name:</strong> <?php echo e(optional($test->test)->testName ?? 'N/A'); ?></p>
            <p><strong>Test Type:</strong> <?php echo e($test->testTypeName ?? 'N/A'); ?></p>
        </div>
    </div>

    <h3>Test Ranges</h3>
    <form action="<?php echo e(route('report.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        
        <input type="hidden" name="ctId" value="<?php echo e($ctId); ?>">
        

        <input type="hidden" name="reportId" value="<?php echo e($reportId); ?>">
        <input type="hidden" name="repoterId" value="<?php echo e(auth()->user()->id); ?>">

        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Range ID</th>
                    <th>Ref. Range Name</th>
                    <th>Gender</th>
                    <th>Min Value</th>
                    <th>Max Value</th>
                    <th>Unit</th>
                    <th>Enter Value</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $test->testRanges; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $range): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($range->testRangeId); ?></td>
                    <td><?php echo e($range->testTypeName); ?></td>
                    <td><?php echo e($range->gender); ?></td>
                    <td><?php echo e($range->minRange); ?></td>
                    <td><?php echo e($range->maxRange); ?></td>
                    <td><?php echo e($range->unit); ?></td>
                    <td>
                        <input type="hidden" name="testRangeId[]" value="<?php echo e($range->testRangeId); ?>">
                        <input type="number" name="reportValue[]" class="form-control" required>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <button type="submit" class="btn btn-primary">Submit Report</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('reporter.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/htdocs/fyp/resources/views/reporter/pages/test-report.blade.php ENDPATH**/ ?>