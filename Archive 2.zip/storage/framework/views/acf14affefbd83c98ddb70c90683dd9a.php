<?php $__env->startSection('content'); ?>
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">

<div class="container-fluid my-4">

  
  <div class="row mb-3">
    <div class="col">
      <h2 class="fw-bold">Sales vs. Expenses</h2>
    </div>
  </div>

  
  <div class="row g-3 mb-4">
    <div class="col-md-4">
      <input
        type="text" id="searchInput"
        class="form-control"
        placeholder="Search customer, type, detail, date..."
      >
    </div>
    <div class="col-md-3">
      <input type="date" id="fromDate" class="form-control">
    </div>
    <div class="col-md-3">
      <input type="date" id="toDate" class="form-control">
    </div>
    <div class="col-md-2 d-flex align-items-end">
      <button id="resetBtn" class="btn btn-secondary w-100">Reset All</button>
    </div>
  </div>

  

<div class="row row-cols-1 row-cols-md-5 g-3 mb-4">
  
  <div class="col">
    <div class="card h-100 shadow-sm border-0">
      <div class="card-body text-center py-4">
        <i class="bi bi-piggy-bank display-6 text-success mb-2"></i>
        <h6 class="text-uppercase text-muted mb-1">Total Sales</h6>
        <h3 id="totalSalesCard" class="fw-bold">₹<?php echo e(number_format($totalSales,2)); ?></h3>
      </div>
    </div>
  </div>

  
  <div class="col">
    <div class="card h-100 shadow-sm border-0">
      <div class="card-body text-center py-4">
        <i class="bi bi-cash-stack display-6 text-danger mb-2"></i>
        <h6 class="text-uppercase text-muted mb-1">Total Debits</h6>
        <h3 id="totalDebitsCard" class="fw-bold">₹<?php echo e(number_format($totalDebits,2)); ?></h3>
      </div>
    </div>
  </div>

  
  <div class="col">
    <div class="card h-100 shadow-sm border-0">
      <div class="card-body text-center py-4">
        <i class="bi bi-box-seam display-6 text-warning mb-2"></i>
        <h6 class="text-uppercase text-muted mb-1">Stock Cost</h6>
        <h3 id="totalStockCard" class="fw-bold">₹<?php echo e(number_format($totalStockCost,2)); ?></h3>
      </div>
    </div>
  </div>

  
  <div class="col">
    <div class="card h-100 shadow-sm border-0">
      <div class="card-body text-center py-4">
        <i class="bi bi-bank2 display-6 text-info mb-2"></i>
        <h6 class="text-uppercase text-muted mb-1">Total Credits</h6>
        <h3 id="totalCreditsCard" class="fw-bold">₹<?php echo e(number_format($totalCredits,2)); ?></h3>
      </div>
    </div>
  </div>

  
  <div class="col">
    <div class="card h-100 shadow-sm border-0">
      <div class="card-body text-center py-4">
        <i class="bi bi-receipt display-6 text-secondary mb-2"></i>
        <h6 class="text-uppercase text-muted mb-1">Total Expense</h6>
        <h3 id="totalExpenseCard" class="fw-bold">₹<?php echo e(number_format($totalExpense,2)); ?></h3>
      </div>
    </div>
  </div>
</div>


<div class="row mb-5">
  <div class="col-12">
    <div class="card bg-dark text-white shadow-lg border-0">
      <div class="card-body text-center py-5">
        <h5 class="text-uppercase text-light mb-3">Net Profit</h5>
        <h1 id="netProfitCard" class="display-1 fw-bold">
          ₹<?php echo e(number_format($net,2)); ?>

        </h1>
      </div>
    </div>
  </div>
</div>


  
  <div class="row g-4">
    
    <div class="col-md-6">
      <div class="card shadow-sm">
        <div class="card-header bg-light"><h5 class="mb-0">Sales</h5></div>
        <div class="card-body p-0">
          <table class="table table-hover mb-0" id="salesTable">
            <thead class="table-light">
              <tr>
                <th>#</th>
                <th>Customer</th>
                <th class="text-end">Received</th>
                <th>Date</th>
              </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $salesPaginator; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr
                data-date="<?php echo e($sale->created_at->toDateString()); ?>"
                data-search="<?php echo e(strtolower($sale->customer->name.' '.$sale->recieved)); ?>"
                data-amount="<?php echo e($sale->recieved); ?>"
              >
                <td><?php echo e($loop->iteration + ($salesPaginator->currentPage()-1)*$salesPaginator->perPage()); ?></td>
                <td><?php echo e($sale->customer->name); ?></td>
                <td class="text-end text-success">₹<?php echo e(number_format($sale->recieved,2)); ?></td>
                <td><?php echo e($sale->created_at->format('Y-m-d')); ?></td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
        <div class="card-footer">
          <?php echo e($salesPaginator->links('pagination::bootstrap-5')); ?>

        </div>
      </div>
    </div>

    
    <div class="col-md-6">
      <div class="card shadow-sm">
        <div class="card-header bg-light"><h5 class="mb-0">Expenses</h5></div>
        <div class="card-body p-0">
          <table class="table table-hover mb-0" id="expensesTable">
            <thead class="table-light">
              <tr>
                <th>#</th>
                <th>Type</th>
                <th>Detail</th>
                <th class="text-end">Amount</th>
                <th>Date</th>
              </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $expensesPaginator; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr
                data-date="<?php echo e($e['date']); ?>"
                data-search="<?php echo e(strtolower($e['type'].' '.$e['detail'])); ?>"
                data-amount="<?php echo e($e['amount']); ?>"
              >
                <td><?php echo e($loop->iteration + ($expensesPaginator->currentPage()-1)*$expensesPaginator->perPage()); ?></td>
                <td><?php echo e($e['type']); ?></td>
                <td><?php echo e($e['detail']); ?></td>
                <td class="text-end <?php echo e($e['amount']<0 ? 'text-primary' : 'text-danger'); ?>">
                  <?php echo e($e['amount'] < 0
                     ? '-₹'.number_format(abs($e['amount']),2)
                     : '₹'.number_format($e['amount'],2)); ?>

                </td>
                <td><?php echo e($e['date']); ?></td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
        <div class="card-footer">
          <?php echo e($expensesPaginator->links('pagination::bootstrap-5', ['pageName'=>'expenses_page'])); ?>

        </div>
      </div>
    </div>
  </div>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<link
  href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css"
  rel="stylesheet"
/>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
  const salesRows   = Array.from(document.querySelectorAll('#salesTable tbody tr'));
  const expenseRows = Array.from(document.querySelectorAll('#expensesTable tbody tr'));
  const fromInput   = document.getElementById('fromDate');
  const toInput     = document.getElementById('toDate');
  const searchInput = document.getElementById('searchInput');

  function applyComparisonFilters() {
    const from = fromInput.value;
    const to   = toInput.value;
    const term = searchInput.value.toLowerCase();

    let sumSales = 0, sumDebits = 0, sumStock = 0, sumCredits = 0;

    // Sales
    salesRows.forEach(row => {
      const date = row.dataset.date;
      const txt  = row.dataset.search;
      const amt  = parseFloat(row.dataset.amount);
      const inDate   = (!from || date >= from) && (!to || date <= to);
      const inSearch = !term || txt.includes(term);
      row.style.display = (inDate && inSearch) ? '' : 'none';
      if (inDate && inSearch) sumSales += amt;
    });

    // Expenses breakdown
    expenseRows.forEach(row => {
      const date = row.dataset.date;
      const txt  = row.dataset.search;
      const amt  = parseFloat(row.dataset.amount);
      const inDate   = (!from || date >= from) && (!to || date <= to);
      const inSearch = !term || txt.includes(term);
      row.style.display = (inDate && inSearch) ? '' : 'none';
      if (inDate && inSearch) {
        if (txt.startsWith('debit')) sumDebits += amt;
        else if (txt.startsWith('stock')) sumStock += amt;
        else if (txt.startsWith('credit')) sumCredits += amt;
      }
    });

    const totalExpense = sumDebits + sumStock - sumCredits;
    const net = sumSales - totalExpense;

    document.getElementById('totalSalesCard')  .innerText = '₹' + sumSales.toFixed(2);
    document.getElementById('totalDebitsCard') .innerText = '₹' + sumDebits.toFixed(2);
    document.getElementById('totalStockCard')  .innerText = '₹' + sumStock.toFixed(2);
    document.getElementById('totalCreditsCard').innerText = '₹' + sumCredits.toFixed(2);
    document.getElementById('totalExpenseCard').innerText = '₹' + totalExpense.toFixed(2);
    document.getElementById('netProfitCard')   .innerText = '₹' + net.toFixed(2);
  }

  fromInput.addEventListener('change', applyComparisonFilters);
  toInput  .addEventListener('change', applyComparisonFilters);
  searchInput.addEventListener('input', applyComparisonFilters);

  document.getElementById('resetBtn').addEventListener('click', () => {
    fromInput.value   = '';
    toInput.value     = '';
    searchInput.value = '';
    applyComparisonFilters();
  });

  // Initialize totals and filtering
  applyComparisonFilters();
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/htdocs/fyp/resources/views/admin/pages/reports/comparison.blade.php ENDPATH**/ ?>