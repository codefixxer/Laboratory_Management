<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Pending Tests</h2>

    <!-- Search Bar -->
    <div class="mb-3">
        <input type="text" id="searchInput" class="form-control" placeholder="Search by Name or Phone">
    </div>

    <table class="table table-striped">
        <thead>
            <tr>
                <th>Customer ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Tests</th>
                <th>Comments</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody id="customerTable">
            <?php $__currentLoopData = $pendingTests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($customer->customerId); ?></td>
                <td class="customer-name"><?php echo e($customer->name); ?></td>
                <td><?php echo e($customer->email); ?></td>
                <td class="customer-phone"><?php echo e($customer->phone); ?></td>
                <td>
                    <?php $__currentLoopData = $customer->customerTests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $test): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <span class="badge bg-secondary"><?php echo e($test->test->testName); ?> - <?php echo e($test->testStatus); ?></span><br>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>
                <td><?php echo e($customer->comment); ?></td>
                <td>
                    <a href="<?php echo e(route('sampler.testDetails', $customer->customerId)); ?>" class="btn btn-success">View Test Details</a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>

<!-- JavaScript for Searching -->
<script>
    document.getElementById("searchInput").addEventListener("keyup", function() {
        let filter = this.value.toLowerCase();
        let rows = document.querySelectorAll("#customerTable tr");

        rows.forEach(row => {
            let name = row.querySelector(".customer-name").textContent.toLowerCase();
            let phone = row.querySelector(".customer-phone").textContent.toLowerCase();

            if (name.includes(filter) || phone.includes(filter)) {
                row.style.display = "";
            } else {
                row.style.display = "none";
            }
        });
    });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('sampler.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/htdocs/fyp/resources/views/sampler/pages/pending.blade.php ENDPATH**/ ?>