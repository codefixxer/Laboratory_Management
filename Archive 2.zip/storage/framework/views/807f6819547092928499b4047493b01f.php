<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <h2 class="mb-4">Accepted Reports</h2>

    <?php if($reports->isEmpty()): ?>
        <p>No accepted reports found.</p>
    <?php else: ?>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Report ID</th>
                    <th>Customer Name</th>
                    <th>Test Name</th>
                    <th>Sign Status</th>
                    <th>Created Date</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($report->reportId); ?></td>
                        <td><?php echo e($report->customerTest->customer->name ?? 'N/A'); ?></td>
                        <td><?php echo e($report->customerTest->test->testName ?? 'N/A'); ?></td>
                        <td><?php echo e(ucfirst($report->signStatus)); ?></td>
                        <td><?php echo e($report->created_at); ?></td>
                        <td>
                            <a href="<?php echo e(route('viewReport', $report->reportId)); ?>" class="btn btn-info">View Report</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('manager.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/htdocs/fyp/resources/views/manager/pages/Accepted_reports/accepted-reports.blade.php ENDPATH**/ ?>