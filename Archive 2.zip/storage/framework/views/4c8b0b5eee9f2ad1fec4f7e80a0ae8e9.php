 
 
<footer class="footer mt-4">
    <div class="container-fluid">
        <div class="row">
            <div class="col fs-13 text-muted text-center py-2">
                &copy; <script>document.write(new Date().getFullYear())</script> MediCore Laboratory System &mdash; All Rights Reserved.
                <br>
                Empowering Healthcare With Innovation. Made with <span class="fas fa-heart text-danger"></span> by <a href="#!" class="text-reset fw-semibold">MediCore Team</a>.
            </div>
        </div>
    </div>
</footer>

<?php /**PATH /Applications/XAMPP/htdocs/fyp/resources/views/admin/layouts/footer.blade.php ENDPATH**/ ?>