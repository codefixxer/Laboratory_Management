<?php $__env->startSection('content'); ?>

<?php $__env->startSection('breadcrumb_parent', 'User Management'); ?>
<?php $__env->startSection('breadcrumb_child', 'Create Users'); ?>


   

    <!-- Add New User Form -->
    <div class="row">
        <div class="col-xl-12">
            <div class="card">
                <div class="card-header">
                    <h5 class="card-title mb-0"><?php echo $__env->yieldContent('breadcrumb_child'); ?></h5>
                </div><!-- end card header -->
                <div class="card-body">
               <form method="POST" action="<?php echo e(isset($user) ? route('admin.users.update', $user->id) : route('admin.users.store')); ?>" enctype="multipart/form-data" id="userForm">
    <?php echo csrf_field(); ?>
    <?php if(isset($user)): ?>
        <?php echo method_field('PUT'); ?>
    <?php endif; ?>
    <div class="row">
        <!-- Name -->
        <div class="col-md-6 mb-3">
            <label for="name" class="form-label">Full Name</label>
            <input type="text" name="name" id="name" class="form-control" placeholder="Enter full name" value="<?php echo e(old('name', isset($user) ? $user->name : '')); ?>" required>
        </div>
        
        <!-- Email -->
        <div class="col-md-6 mb-3">
            <label for="email" class="form-label">Email Address</label>
            <input type="email" name="email" id="email" class="form-control" placeholder="Enter email address" value="<?php echo e(old('email', isset($user) ? $user->email : '')); ?>" required>
        </div>
        
        <!-- Password -->
        <div class="col-md-6 mb-3">
            <label for="password" class="form-label">Password</label>
            <input type="password" name="password" id="password" class="form-control" placeholder="Enter password" <?php echo e(isset($user) ? '' : 'required'); ?>>
        </div>
        
        <!-- Confirm Password -->
        <div class="col-md-6 mb-3">
            <label for="password_confirmation" class="form-label">Confirm Password</label>
            <input type="password" name="password_confirmation" id="password_confirmation" class="form-control" placeholder="Confirm password" <?php echo e(isset($user) ? '' : 'required'); ?>>
        </div>
        
        <!-- Role -->
        <?php
            // These variables must be passed from your controller:
            // $usedRoles: array of ['manager', 'sampler', 'reporter'] already present in DB, except current user in edit
            $allRoles = [
                'manager' => 'Manager',
                'sampler' => 'Sampler',
                'reporter' => 'Reporter',
                'receptionist' => 'Receptionist'
            ];
            $selectedRole = old('role', isset($user) ? $user->role : '');
            $availableRoles = [];
            foreach ($allRoles as $key => $label) {
                if ($key == 'receptionist' || !in_array($key, $usedRoles) || $selectedRole == $key) {
                    $availableRoles[$key] = $label;
                }
            }
        ?>

        <div class="col-md-6 mb-3">
            <label for="role" class="form-label">User Role</label>
            <select name="role" id="role" class="form-select" required>
                <option value="" disabled <?php echo e($selectedRole == '' ? 'selected' : ''); ?>>Select Role</option>
                <?php $__currentLoopData = $availableRoles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($value); ?>" <?php echo e($selectedRole == $value ? 'selected' : ''); ?>>
                        <?php echo e($label); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php $__errorArgs = ['role'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <!-- Status -->
        <div class="col-md-6 mb-3">
            <label for="status" class="form-label">Status</label>
            <select name="status" id="status" class="form-select" required>
                <option value="" disabled <?php echo e(old('status', isset($user) ? $user->status : '') == '' ? 'selected' : ''); ?>>Select Status</option>
                <option value="active" <?php echo e(old('status', isset($user) ? $user->status : '') == 'active' ? 'selected' : ''); ?>>Active</option>
                <option value="inactive" <?php echo e(old('status', isset($user) ? $user->status : '') == 'inactive' ? 'selected' : ''); ?>>Inactive</option>
            </select>
        </div>

        <!-- Phone Number (Optional) -->
        <div class="col-md-6 mb-3">
            <label for="phone" class="form-label">Phone Number</label>
            <input type="text" name="phone" id="phone" class="form-control" placeholder="Enter phone number" value="<?php echo e(old('phone', isset($user) ? $user->phone : '')); ?>">
        </div>

        <!-- Address (Optional) -->
        <div class="col-md-6 mb-3">
            <label for="address" class="form-label">Address</label>
            <input type="text" name="address" id="address" class="form-control" placeholder="Enter address" value="<?php echo e(old('address', isset($user) ? $user->address : '')); ?>">
        </div>

        <!-- Profile Picture (Optional) -->
        <div class="col-md-6 mb-3">
            <label for="profile_picture" class="form-label">Profile Picture</label>
            <input type="file" name="profile_picture" id="profile_picture" class="form-control" accept="image/*">
            <?php if(isset($user) && $user->profile_picture): ?>
                <small>Current Picture: <a href="<?php echo e(asset('storage/' . $user->profile_picture)); ?>" target="_blank">View</a></small>
            <?php endif; ?>
        </div>

        <!-- Submit Button -->
        <div class="col-12">
            <button type="submit" class="btn btn-primary">
                <?php echo e(isset($user) ? 'Update User' : 'Create User'); ?>

            </button>
        </div>
    </div>
</form>

                    
                    <script>
                    document.addEventListener('DOMContentLoaded', function () {
                        const userForm = document.getElementById('userForm');
                        userForm.addEventListener('submit', function (e) {
                            const password = document.getElementById('password').value;
                            const confirmPassword = document.getElementById('password_confirmation').value;
                            // Only validate if password fields are not empty (i.e., during creation or when updating password)
                            if(password || confirmPassword){
                                if(password !== confirmPassword){
                                    e.preventDefault();
                                    alert("Passwords do not match!");
                                }
                            }
                        });
                    });
                    </script>
                    
                    
                </div><!-- end card-body -->
            </div><!-- end card -->
        </div><!-- end col -->
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/htdocs/fyp/resources/views/admin/pages/users/create.blade.php ENDPATH**/ ?>