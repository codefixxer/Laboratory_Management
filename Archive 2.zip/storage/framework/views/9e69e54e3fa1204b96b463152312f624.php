<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <h2 class="mb-4">Report Details</h2>

    <div class="card">
        <div class="card-body">
            <h4>Customer Information</h4>
            <p><strong>Name:</strong> <?php echo e($report->customerTest->customer->name ?? 'N/A'); ?></p>
            <p><strong>Email:</strong> <?php echo e($report->customerTest->customer->email ?? 'N/A'); ?></p>
            <p><strong>Phone:</strong> <?php echo e($report->customerTest->customer->phone ?? 'N/A'); ?></p>
        </div>
    </div>

    <div class="card mt-3">
        <div class="card-body">
            <h4>Test Information</h4>
            <p><strong>Test Name:</strong> <?php echo e($report->customerTest->test->testName ?? 'N/A'); ?></p>
            <p><strong>Sample Type:</strong> <?php echo e($report->customerTest->test->typeSample ?? 'N/A'); ?></p>
            <p><strong>How Sample Collected:</strong> <?php echo e($report->customerTest->test->howSample ?? 'N/A'); ?></p>
        </div>
    </div>
    <div class="card mt-3">
        <div class="card-body">
            
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Range Name</th>
                        <th>Min Value</th>
                        <th>Max Value</th>
                        <th>Unit</th>
                        <th>Entered Value</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $testRanges; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $range): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($range->testTypeName); ?></td>
                            <td><?php echo e($range->minRange); ?></td>
                            <td><?php echo e($range->maxRange); ?></td>
                            <td><?php echo e($range->unit); ?></td>
                            <td>
                                <?php echo e(isset($report->reportChildren[$index]) ? $report->reportChildren[$index]->reportValue : 'N/A'); ?>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
    
    <div class="card mt-3">
        <div class="card-body">
            <h4>Actions</h4>
            <p><strong>Current Sign Status:</strong> <?php echo e(ucfirst($report->signStatus)); ?></p>
    
            <form action="<?php echo e(route('manager.update-sign-status', $report->reportId)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="action" id="actionInput">
    
                <button type="submit" class="btn btn-success" onclick="setAction('accepted')">Accept</button>
                <button type="submit" class="btn btn-danger" onclick="setAction('revoked')">Revoke</button>
            </form>
        </div>
    </div>
    
    <script>
        function setAction(status) {
            document.getElementById('actionInput').value = status;
        }
    </script>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('manager.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/htdocs/fyp/resources/views/manager/pages/Pending_report/report-view.blade.php ENDPATH**/ ?>