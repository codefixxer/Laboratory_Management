<?php $__env->startSection('content'); ?>

<?php $__env->startSection('breadcrumb_parent', 'External Panel'); ?>
<?php $__env->startSection('breadcrumb_child', 'View Panel'); ?>

<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title mb-0"><?php echo $__env->yieldContent('breadcrumb_child'); ?></h5>
            </div>

            <div class="card-body">
                <!-- External Panel Table -->
                <table id="datatable" class="table table-bordered dt-responsive nowrap w-100">
                    <thead>
                        <tr>
                            <th>Panel Name</th>
                            <th>Panel Address</th>
                            <th>Total Credits</th>
                            <th>Remaining Credits</th>
                            <th>Created At</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $externalPanels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $panel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($panel->panelName); ?></td>
                            <td><?php echo e($panel->panelAddrs); ?></td>
                            <td><?php echo e($panel->credits); ?></td>
                            <td><?php echo e($panel->remainingCredits); ?></td>
                            <td><?php echo e($panel->created_at->format('Y-m-d')); ?></td>
                            <td>
                                <a href="<?php echo e(route('admin.external.edit', $panel->extPanelId)); ?>" class="btn btn-sm btn-primary">Edit</a>
                                <form action="<?php echo e(route('admin.external.destroy', $panel->extPanelId)); ?>" method="POST" class="d-inline-block" onsubmit="return confirm('Are you sure you want to delete this panel?');">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <!-- End Table -->
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/htdocs/fyp/resources/views/admin/pages/externalpanel/view.blade.php ENDPATH**/ ?>