<?php $__env->startSection('content'); ?>

<?php $__env->startSection('breadcrumb_parent', 'Allocated Customers'); ?>
<?php $__env->startSection('breadcrumb_child', 'Loyalty Card Allocations'); ?>

<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title mb-0"><?php echo $__env->yieldContent('breadcrumb_child'); ?></h5>
            </div>
            <div class="card-body">
                <?php if(session('success')): ?>
                    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                <?php endif; ?>

                <table class="table table-bordered dt-responsive nowrap w-100">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Phone Number</th>
                            <th>Percentage</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $lcRecords; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <!-- Main row showing LC record details -->
                            <tr>
                                <td><?php echo e($record->id); ?></td>
                                <td><?php echo e($record->phone_number); ?></td>
                                <td><?php echo e($record->percentage); ?>%</td>
                                <td>
                                    <!-- Toggle button for collapsible row -->
                                    <button class="btn btn-sm btn-primary"
                                            data-bs-toggle="collapse"
                                            data-bs-target="#collapse-<?php echo e($record->id); ?>">
                                        Show/Hide Users
                                    </button>
                                    <!-- Delete button -->
                                    <form action="<?php echo e(route('admin.lc.destroy', $record->id)); ?>" method="POST" class="d-inline-block"
                                          onsubmit="return confirm('Are you sure you want to delete this record?');">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button class="btn btn-sm btn-danger" type="submit">
                                            Delete
                                        </button>
                                    </form>
                                </td>
                            </tr>
                            <!-- Collapsible row for allocated customers -->
                            <tr class="collapse" id="collapse-<?php echo e($record->id); ?>">
                                <td colspan="4">
                                    <?php if($record->customers->count()): ?>
                                        <ul class="mb-0">
                                            <?php $__currentLoopData = $record->customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li>
                                                    <?php echo e($customer->name); ?>

                                                    <?php if(!empty($customer->relation)): ?>
                                                        - (<?php echo e($customer->relation); ?>)
                                                    <?php endif; ?>
                                                    <?php if(!empty($customer->email)): ?>
                                                        - <?php echo e($customer->email); ?>

                                                    <?php endif; ?>
                                                </li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    <?php else: ?>
                                        <span>No Customers</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>

            </div><!-- end card-body -->
        </div><!-- end card -->
    </div><!-- end col -->
</div><!-- end row -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/htdocs/fyp/resources/views/admin/pages/lc/aloted.blade.php ENDPATH**/ ?>