<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Customer Information</h2>
    <div class="card p-3">
        <p><strong>Customer ID:</strong> <?php echo e($customer->customerId); ?></p>
        <p><strong>Name:</strong> <?php echo e($customer->name); ?></p>
        <p><strong>Email:</strong> <?php echo e($customer->email); ?></p>
        <p><strong>Phone:</strong> <?php echo e($customer->phone); ?></p>
        <p><strong>Gender:</strong> <?php echo e($customer->gender); ?></p>
    </div>

    <h3 class="mt-4">Test Details</h3>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Test ID</th>
                <th>Test Name</th>
                <th>Sample Type</th>
                <th>How to Collect</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $customer->customerTests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $test): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr id="test-row-<?php echo e($test->addTestId); ?>">
                <td><?php echo e($test->addTestId); ?></td>
                <td><?php echo e($test->test->testName); ?></td>
                <td><?php echo e($test->test->typeSample); ?></td>
                <td><?php echo e($test->test->howSample); ?></td>
                <td>
                    <?php if($test->testStatus == 'pending'): ?>
                        <button class="btn btn-primary collect-sample" 
                                data-test-id="<?php echo e($test->addTestId); ?>"
                                data-customer-id="<?php echo e($test->customerId); ?>">
                            Collect Sample
                        </button>
                    <?php else: ?>
                        <button class="btn btn-success" disabled>Collected</button>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
        </tbody>
    </table>
</div>

<!-- AJAX Script -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
$(document).ready(function(){
    $(".collect-sample").click(function(){
        var addTestId = $(this).data("test-id");
        var customerId = $(this).data("customer-id");
        var button = $(this);

        $.ajax({
            url: "<?php echo e(route('sampler.collectSample')); ?>",
            type: "POST",
            data: {
                _token: "<?php echo e(csrf_token()); ?>",
                addTestId: addTestId,
                customerId: customerId
            },
            success: function(response) {
                if(response.success) {
                    button.replaceWith('<button class="btn btn-success" disabled>Collected</button>');
                }
            },
            error: function() {
                alert("Error updating test status.");
            }
        });
    });
});

  
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('sampler.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/htdocs/fyp/resources/views/sampler/pages/test-details.blade.php ENDPATH**/ ?>