<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Collected Tests</h2>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Customer ID</th>
                <th>Customer Name</th>
                <th>Tests</th>
                <th>Comment</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php
                $groupedReports = $reports->groupBy('customer.customerId'); 
            ?>

            <?php $__currentLoopData = $groupedReports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customerId => $customerReports): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($customerReports->first()->customer->customerId); ?></td>
                <td><?php echo e($customerReports->first()->customer->name); ?></td>
                <td>
                    <?php $__currentLoopData = $customerReports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <span class="badge bg-secondary"><?php echo e($report->test->testName); ?></span>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>
                <td><?php echo e($customerReports->first()->customer->comment); ?></td>
                <td>
                    <a href="<?php echo e(route('reporter.viewTestDetails', $customerId)); ?>" class="btn btn-primary">View Test Details</a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('reporter.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/htdocs/fyp/resources/views/reporter/pages/reports.blade.php ENDPATH**/ ?>