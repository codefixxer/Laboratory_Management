<?php $__env->startSection('content'); ?>
  
  

  <div class="row mb-4">
    
    <div class="col-md-7">
      <div class="card shadow-sm h-100">
        <div class="card-header">
          <h5 class="mb-0">My Sales Overview</h5>
        </div>
        <div class="card-body">
          <?php echo $salesOverviewChart->container(); ?>

        </div>
      </div>
    </div>

  
<div class="col-md-5">
  <div class="row g-3">
    <?php $__currentLoopData = [
      ['Customers',      $totalCustomers,     'primary',   'fa-users'],
      ['Customer Tests', $totalCustomerTests, 'success',   'fa-clipboard-check'],
      ['Payments',       $totalPayments,      'info',      'fa-money-bill-wave'],
      ['Debits',         $totalDebits,        'warning',   'fa-arrow-down'],
      ['Credits',        $totalCredits,       'danger',    'fa-arrow-up'],
      ['Stock Entries',  $totalStocks,        'secondary', 'fa-boxes-stacked']
    ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$label, $value, $color, $icon]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="col-6">
        <div class="card shadow-sm border-0 position-relative overflow-hidden h-100">
          <div class="position-absolute top-0 start-0 w-100 h-100"
               style="background: rgba(var(--bs-<?php echo e($color); ?>-rgb), .05);"></div>
          <div class="card-body position-relative">
            <div class="d-flex align-items-center mb-3">
              <div class="bg-<?php echo e($color); ?> text-white rounded-circle d-flex justify-content-center align-items-center me-3"
                   style="width:52px; height:52px; box-shadow:0 2px 8px rgba(0,0,0,.07);">
                <i class="fa-solid <?php echo e($icon); ?> fs-3"></i>
              </div>
              <div>
                <h6 class="text-uppercase text-<?php echo e($color); ?> mb-1" style="letter-spacing:.8px;"><?php echo e($label); ?></h6>
                <h2 class="fw-bold mb-0"><?php echo e(number_format($value)); ?></h2>
              </div>
            </div>
            <small class="text-muted d-block text-end">Last 30 days</small>
          </div>
        </div>
      </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
</div>

  </div>

  
  <div class="row g-4 mt-5">
    <div class="col-12 col-md-6 col-xl-3">
      <div class="card shadow-sm h-100">
        <div class="card-header">Sales Breakdown</div>
        <div class="card-body">
          <?php echo $salesBreakdownChart->container(); ?>

        </div>
      </div>
    </div>

    <div class="col-12 col-md-6 col-xl-3">
      <div class="card shadow-sm h-100">
        <div class="card-header">Debits vs Credits</div>
        <div class="card-body">
          <?php echo $debitCreditChart->container(); ?>

        </div>
      </div>
    </div>

    <div class="col-12 col-md-6 col-xl-3">
      <div class="card shadow-sm h-100">
        <div class="card-header">Expense Breakdown</div>
        <div class="card-body">
          <?php echo $expenseChart->container(); ?>

        </div>
      </div>
    </div>

    <div class="col-12 col-md-6 col-xl-3">
      <div class="card shadow-sm h-100">
        <div class="card-header">Inventory Composition</div>
        <div class="card-body">
          <?php echo $inventoryChart->container(); ?>

        </div>
      </div>
    </div>
  </div>

  
  <div class="row gy-4 mt-5">
    <div class="col-lg-6">
      <div class="card shadow-sm h-100">
        <div class="card-header bg-light"><h5 class="mb-0">Daily Sales (Last 30 days)</h5></div>
        <div class="card-body">
          <?php echo $dailySalesAreaChart->container(); ?>

        </div>
      </div>
    </div>

    <div class="col-lg-6">
      <div class="card shadow-sm h-100">
        <div class="card-header bg-light"><h5 class="mb-0">Tests by Category</h5></div>
        <div class="card-body">
          <?php echo $testCategoryPieChart->container(); ?>

        </div>
      </div>
    </div>
  </div>

  <div class="row gy-4 mt-4">
    <div class="col-12">
      <div class="card shadow-sm h-100">
        <div class="card-header bg-light"><h5 class="mb-0">Monthly Debits vs Credits</h5></div>
        <div class="card-body">
          <?php echo $debitCreditAreaChart->container(); ?>

        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
  <script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>
  <?php echo $salesOverviewChart->script(); ?>

  <?php echo $salesBreakdownChart->script(); ?>

  <?php echo $debitCreditChart->script(); ?>

  <?php echo $expenseChart->script(); ?>

  <?php echo $inventoryChart->script(); ?>

  <?php echo $dailySalesAreaChart->script(); ?>

  <?php echo $testCategoryPieChart->script(); ?>

  <?php echo $debitCreditAreaChart->script(); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('receptionist.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/htdocs/fyp/resources/views/receptionist/pages/dashboard.blade.php ENDPATH**/ ?>