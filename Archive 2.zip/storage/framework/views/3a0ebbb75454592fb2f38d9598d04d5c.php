<!DOCTYPE html>
<html lang="en">
   
<?php echo $__env->make('patient.layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <body data-menu-color="light" data-sidebar="default">

        <div id="app-layout">
            <?php echo $__env->make('patient.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('patient.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>           
            <div class="content-page">
                <div class="content">
<!-- resources/views/admin/partials/alerts.blade.php -->
<?php if(session('success')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?php echo e(session('success')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>

<?php if(session('error')): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <?php echo e(session('error')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <ul class="mb-0">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>



    <div class="container-fluid">
        <div class="py-3 d-flex align-items-sm-center flex-sm-row flex-column">
          
            <div class="text-end">
                <ol class="breadcrumb m-0 py-0">
                    <li class="breadcrumb-item">
                        <a href="javascript:void(0);"><?php echo $__env->yieldContent('breadcrumb_parent', 'Labortary Management System'); ?></a>
                    </li>
                    <li class="breadcrumb-item active">
                        <?php echo $__env->yieldContent('breadcrumb_child', '(LMS)'); ?>
                    </li>
                </ol>
            </div>
        </div>

        <?php echo $__env->yieldContent('content'); ?>
    </div>



                </div>
                    <?php echo $__env->make('patient.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>  
        </div>
        <script>
            window.onpageshow = function (event) {
                // If the page was restored from bfcache, force a reload:
                if (event.persisted) {
                    window.location.reload();
                }
            };
            </script>
             <?php echo $__env->yieldContent('scripts'); ?>
            <?php echo $__env->make('patient.layouts.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


           
                
                
    </body>

        
        
        
</html><?php /**PATH /Applications/XAMPP/htdocs/fyp/resources/views/patient/layouts/app.blade.php ENDPATH**/ ?>