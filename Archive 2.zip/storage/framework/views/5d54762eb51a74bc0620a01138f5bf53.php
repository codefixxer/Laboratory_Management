        <script src="<?php echo e(asset('assets/libs/jquery/jquery.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/libs/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/libs/simplebar/simplebar.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/libs/node-waves/waves.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/libs/waypoints/lib/jquery.waypoints.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/libs/jquery.counterup/jquery.counterup.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/libs/feather-icons/feather.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/libs/apexcharts/apexcharts.min.js')); ?>"></script>
        <script src="https://apexcharts.com/samples/assets/stock-prices.js"></script>
        <script src="<?php echo e(asset('assets/js/pages/crm-dashboard.init.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/app.js')); ?>"></script>






            <?php /**PATH /Applications/XAMPP/htdocs/fyp/resources/views/receptionist/layouts/scripts.blade.php ENDPATH**/ ?>